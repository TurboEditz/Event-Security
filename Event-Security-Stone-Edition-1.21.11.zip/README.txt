EVENT SECURITY — STONE DISGUISE RESOURCE PACK
Minecraft Java 1.21.11 target

This expanded edition replaces a large set of common vanilla block textures with a stone texture, including ores, storage/loot blocks, building blocks, wood families, colored blocks, and many decorative blocks.

IMPORTANT LIMITATIONS
- This is a broad vanilla texture override, not a mathematically complete override of every possible block texture in every Minecraft version.
- Modded blocks and custom server resource-pack assets are not covered.
- Some blocks use multiple textures, connected textures, entity/block-entity models, or special render layers, so a texture override may not fully disguise every appearance.
- A resource pack only changes client visuals. It does not conceal coordinates, chunk data, block states, inventories, screenshots, or server-side information.
- Require the pack in server.properties if you want players to accept it to join.

INSTALL
1. Host this ZIP at a direct-download URL.
2. Set resource-pack=<direct ZIP URL> in server.properties.
3. Set require-resource-pack=true if desired.
4. Restart the server.
